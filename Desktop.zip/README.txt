A Pen created at CodePen.io. You can find this one at https://codepen.io/tholex/pen/zvZvNb.

 Example for my workshop: https://open-sessions.thinkful.com/css-styling-typography-and-pancakes-335/